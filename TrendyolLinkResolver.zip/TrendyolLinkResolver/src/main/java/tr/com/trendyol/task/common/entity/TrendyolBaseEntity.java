package tr.com.trendyol.task.common.entity;

import javax.persistence.*;
import java.time.OffsetDateTime;

/*@MappedSuperclass
public class TrendyolBaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = )
    @SequenceGenerator()
    private Long id;

}*/
