package tr.com.trendyol.task.common.entity.sequence;

import org.hibernate.MappingException;
import org.hibernate.id.enhanced.SequenceStyleGenerator;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.type.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

/**
 * Veritabani nesneleri icin sequence olusturmak amaciyla kullanilan strategy sinifidir.
 *
 * @author fferoglu
 */
public class TrandyolEntitySequenceGeneratorStrategy extends SequenceStyleGenerator {

    private static final Logger logger = LoggerFactory.getLogger(TrandyolEntitySequenceGeneratorStrategy.class);

    @Override
    public void configure(Type type, Properties params, ServiceRegistry serviceRegistry) throws MappingException {
        super.configure(type, params, serviceRegistry);
    }
}
