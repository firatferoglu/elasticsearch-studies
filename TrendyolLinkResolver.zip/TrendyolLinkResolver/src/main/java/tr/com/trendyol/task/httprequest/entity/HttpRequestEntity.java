package tr.com.trendyol.task.httprequest.entity;


/*
import javax.persistence.*;

@Entity
@Table(name = "HTTP_REQUEST", schema = "linkresolver")
public class HttpRequestEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "http_request_generator")
    @SequenceGenerator(name = "http_request_generator", sequenceName = "http_request_seq")
    private Long id;

    private
}
*/
