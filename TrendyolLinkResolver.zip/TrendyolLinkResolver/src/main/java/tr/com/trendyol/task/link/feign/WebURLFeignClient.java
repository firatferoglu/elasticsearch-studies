package tr.com.trendyol.task.link.feign;

public class WebURLFeignClient {
}
