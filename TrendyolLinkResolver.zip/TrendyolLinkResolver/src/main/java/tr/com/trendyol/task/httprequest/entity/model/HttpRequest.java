package tr.com.trendyol.task.httprequest.entity.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.util.Date;

@Data
@Document(indexName = "url-deeplink-request")
public class HttpRequest {

    @Id
    private String id;

    private String requestBody;

    private String responseBody;

    @Field(type = FieldType.Date)
    private Date requestDate;

    @Field(type = FieldType.Date)
    private Date responseDate;

}
