package tr.com.trendyol.task.common.entity.annotation;

/**
 * Veritabani nesnesine sequence adinin verilmesini saglayan annotationdir.
 *
 * @author fferoglu
 */
public @interface TrendyolEntitySequence {

    /**
     * Sequence adinin belirtildigi parametredir.
     *
     * @return String sequence adi
     */
    String name();
}
