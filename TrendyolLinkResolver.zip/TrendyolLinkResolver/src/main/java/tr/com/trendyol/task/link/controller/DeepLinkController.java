package tr.com.trendyol.task.link.controller;

public class DeepLinkController {
}
