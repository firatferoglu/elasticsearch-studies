package tr.com.trendyol.task.common.entity.constant;

public final class TrendyolBaseEntityConstants {

    /*// Sequence
    public static final String SEQUENCE_GENERATOR;
    public static final String SEQUENCE_GENERATOR_STRATEGY;
    public static final String SEQUENCE_GENERATOR_INITIAL_PARAM;
    public static final String SEQUENCE_GENERATOR_INCREMENT_PARAM;
    public static final String SEQUENCE_GENERATOR_OPT_PARAM;
    public static final String SEQUENCE_GENERATOR_STRATEGY_POOL_PARAM;

    // Columns
    public static final String COLUMN_ID;


    private TrendyolBaseEntityConstants() {}*/
}
