package tr.com.trendyol.task.link.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class WebURL implements Serializable {
    private String url;
}
