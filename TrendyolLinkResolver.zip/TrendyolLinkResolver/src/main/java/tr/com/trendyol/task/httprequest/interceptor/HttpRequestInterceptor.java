package tr.com.trendyol.task.httprequest.interceptor;

public class HttpRequestInterceptor {
}
